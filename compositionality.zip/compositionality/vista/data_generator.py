import numpy as np


def generate_dummy_categorical_dataset(flags, dataset="training"):
    """ Generate random binary vector dataset with categorical labels """
    v_dim = flags['input_dim']
    num_samples = flags['num_episodes'] if dataset == 'training' else 1000
    n_distractors = flags['num_distractors']

    targets, candidate_sets, labels = [], [], []
    for _ in range(num_samples):
        candidate_set = [np.random.randint(0, 2, size=v_dim) for idx in range(n_distractors + 1)]
        target_idx = np.random.randint(n_distractors + 1)
        target = candidate_set[target_idx]

        candidate_sets.append(candidate_set)  # [1000, 4, 12]
        labels.append(target_idx)  # [1000]
        targets.append(target)  # [1000, 12]

    ## Convert scalar labels to vector
    # labels = np.eye(n_distractors + 1, dtype='uint8')[labels]
    ## Return zipped object
    return zip(targets, candidate_sets, labels)