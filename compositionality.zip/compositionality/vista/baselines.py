"""
baselines:
        Random, Fixed, Perfect, Oracle, Simple (Categorical)

"""

from gcomm.arguments import Arguments
from baseline_models import SpeakerBot, ListenerBot
from gcomm.agent import SpeakerAgent, ListenerAgent
from data_generator import generate_dummy_categorical_dataset
from plot import generate_task_progress, plot_metrics
from gcomm.metrics import topsim_metric, posdis_metric, bosdis_metric, posdis_metric2

import os
import numpy as np
from pathlib import Path
import torch
import torch.optim as optim

SAVE_FIG = False  # save test episodes?
# DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
DEVICE = torch.device("cpu")
flags = Arguments()

LAMBDA = 0.01  # hyper parameter for entropy
lr = 1e-4 # 5e-4

# ======================= Data storage paths ========================== #
run_id = flags['run_id']
path = os.path.join(os.getcwd(), flags['comm_type'] + "_speaker_data/") + "run_" + str(run_id) + "/"
model_load_path = Path(path + "checkpoint_dir")
plot_path = Path(path + "plots")
model_load_path.mkdir(exist_ok=True, parents=True)
plot_path.mkdir(exist_ok=True, parents=True)
log_file = open(path + "log.txt", "w")
log_file.write(str(flags) + '\n')
visualization_path = None
save_model_flag = True
# corr_pear, corr_spear, posdis_arr, bosdis_arr = [], [], [], []


# =======================Save Models======================== #
def save_models(iteration):
    for model_name, model in all_vars.items():
        if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
            model_list = ['speaker_bot', 'listener_bot']
        else:
            model_list = ['listener_bot']
        if model_name in model_list:
            with open(os.path.join(model_load_path, str(iteration) + '_' + model_name), 'wb') as f:
                torch.save(model.state_dict(), f)


def single_loop(data_sample, validation=False, composition_dict=None, bosdis_composition_array=None):
    speaker_out, _ = speaker_agent.transmit(concept=data_sample[0], validation=validation)
    speaker_out = speaker_out.view(1, -1)

    # =======================Measure Composition======================== #
    if validation:
        symbols = ''.join([str(int(x)) for x in speaker_out[0].tolist()])
        str_obs = ''.join([str(x) for x in data_sample[0].tolist()])
        composition_dict[str_obs] = ''.join(symbols)

        # bosdis
        if [int(x) for x in str_obs] not in bosdis_composition_array[0]:
            bosdis_composition_array[0].append([int(x) for x in str_obs])  # attributes
            # if [int(x) for x in symbols] not in bosdis_composition_array[1]:
            bosdis_composition_array[1].append([int(x) for x in symbols])  # messages

    candidates = torch.tensor(np.stack(data_sample[1]), dtype=torch.float32).to(DEVICE)

    # action by policy
    log_prob, entropy, _, action = listener_agent.act(state=(candidates, speaker_out), validate=validation)

    if action == data_sample[2]:
        reward = torch.tensor(1.).to(DEVICE)
    else:
        reward = torch.tensor(0.).to(DEVICE)

    if validation:
        return reward, bosdis_composition_array

    agent_loss = (-log_prob * reward.detach()).mean()
    net_loss = agent_loss - LAMBDA * entropy
    return net_loss, reward


def main():
    # Create directory for visualizations if it doesn't exist.
    flags['output_directory'] = os.path.join(os.getcwd(), flags['output_directory'])
    if flags['output_directory']:
        visualization_path = flags['output_directory']
        if not os.path.exists(visualization_path):
            os.mkdir(visualization_path)

    # generating episodes
    task_rewards = {"'visa'": []}

    train_data = list(generate_dummy_categorical_dataset(flags, "training"))
    test_data = list(generate_dummy_categorical_dataset(flags, "testing"))

    for Episode_count in range(1, flags["num_episodes"] + 1):
        # ==================== Train =================== #
        if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
            all_vars['speaker_bot'].train(True)
        all_vars['listener_bot'].train(True)
        all_vars['optimizer'].zero_grad()
        # run a single training loop
        net_loss, train_rewards = single_loop(train_data[Episode_count - 1], validation=False)
        net_loss.backward()

        all_vars['optimizer'].step()

        # ==================== validation ====================== #
        if Episode_count % 50 == 0:
            val_rewards = 0
            num_val_iter = 50  # number of validation loops/episodes to be run
            if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
                all_vars['speaker_bot'].eval()
            all_vars['listener_bot'].eval()
            composition_dict = dict()
            bosdis_composition_array = [[], []]  # attribute arr, message_arr
            with torch.no_grad():
                for val_iter in range(num_val_iter):
                    val_reward, bosdis_composition_array = \
                        single_loop(test_data[val_iter],
                                    composition_dict=composition_dict,
                                    bosdis_composition_array=bosdis_composition_array,
                                    validation=True)
                    val_rewards += val_reward / num_val_iter
            # task_rewards["'visa'"].extend([val_rewards])

            # =================Measure correlation================== #
            c_p, c_s = topsim_metric(composition_dict)
            # corr_pear.extend([c_p])
            # corr_spear.extend([c_s])
            posdis = posdis_metric2(attributes=torch.tensor(bosdis_composition_array[0]),
                                     messages=torch.tensor(bosdis_composition_array[1]))
            bosdis = bosdis_metric(attributes=torch.tensor(bosdis_composition_array[0]),
                                   messages=torch.tensor(bosdis_composition_array[1]),
                                   vocab_size=5)
            # posdis_arr.extend([posdis])
            # bosdis_arr.extend([bosdis])

            print('episode: {} | val-reward: {} | topsim: {} | posdis: {} | bosdis: {}'.format(Episode_count,
                                                                                                    val_rewards, c_p,
                                                                                                    posdis, bosdis))
            log_file.write('Episode: ' + str(Episode_count) + ' | Train Reward: ' + str(train_rewards.sum().item()) +
                           ' | Val Reward: ' + str(val_rewards.item()) + ' | Train Loss: ' + str(net_loss.item()) +
                           ' | topsim (Pearson): ' + str(c_p) + ' | topsim (Spearman): ' + str(c_s) +
                           ' | posdis: ' + str(posdis) + ' | bosdis: ' + str(bosdis) + "\n")

        # ========================== Plot ============================= #
        if Episode_count % 2000 == 0 and Episode_count != 0:
            # print('------------------Generating plots------------------------')
            # generate_task_progress(task_reward_dict=task_rewards, color='m',
            #                        file_name=os.path.join(plot_path, 'task_progress.png'))
            # plot_metrics(corr_pear, corr_spear, posdis_arr, bosdis_arr,
            #              file_name=os.path.join(plot_path, 'compositionality.png'))
            print(composition_dict)

        # =====================save model====================== #
        if save_model_flag is True:
            if Episode_count % 2000 == 0:
                print('------------------Saving model checkpoint------------------\n')
                save_models(iteration=Episode_count)

        log_file.flush()


if __name__ == "__main__":
    # =================initialize model params and environment============== #

    # ================== Listener-Bot ====================== #
    oracle = True if flags['comm_type'] == 'oracle' else False
    listener_bot = ListenerBot(input_size=flags['input_dim'], output_size=flags['input_dim'],
                               msg_len=flags['input_dim'],
                               oracle=oracle, device=DEVICE).to(DEVICE)
    listener_agent = ListenerAgent(listener_model=listener_bot)

    # ================== Speaker-Bot ====================== #
    speaker_bot = SpeakerBot(comm_type=flags['comm_type'], input_size=flags['input_dim'],
                             hidden_size=flags['input_dim'],
                             output_size=flags['input_dim'], num_msgs=1, device=DEVICE).to(DEVICE)
    speaker_agent = SpeakerAgent(num_msgs=1, msg_len=flags['input_dim'], comm_type=flags['comm_type'],
                                 temp=flags['temp'], speaker_model=speaker_bot, device=DEVICE)

    all_params = list(listener_agent.listener_model.parameters())
    if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
        all_params += list(speaker_agent.speaker_model.parameters())

    optimizer = optim.AdamW(all_params, lr=lr, weight_decay=1e-6)
    all_vars = {'listener_bot': listener_bot, 'speaker_bot': speaker_bot, 'optimizer': optimizer}

    print('\n=================== Baseline [other env Vista]: {} ===================\n'.format(flags['comm_type'].upper()))
    main()

    log_file.close()
