import torch
import torch.nn as nn
import torch.nn.functional as F


# ========================Speaker Module============================ #
class SpeakerBot(nn.Module):
    """
    Speaker has access to the 18-d concept input (size + shape + color + weight + task)
    and transmits 'num_msgs' (n_m) messages of length 'msg_len' (d_m)
    """

    def __init__(self, comm_type, input_size, hidden_size, output_size, num_msgs, device):
        """
        :comm_type: ['categorical', 'binary', 'continuous']
        :input size: 18-d (concept representation)
        :hidden_size: hidden size of RNN
        :output_size: msg_len (d_m)
        :num_msgs: num_msgs (n_m)
        :device: cpu/gpu
        """
        super().__init__()
        # model params
        self.comm_type = comm_type
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size  # msg_len
        self.num_msgs = num_msgs
        self.device = device

        self.output_layer = nn.Sequential(nn.Linear(self.input_size, self.output_size),
                                           nn.ReLU(),
                                           nn.Linear(self.output_size, 2*self.output_size))
        # self.init_input = nn.Parameter(torch.zeros(1, 2*self.hidden_size, device=self.device), requires_grad=True)

    def forward(self, data_input, comm_channel, validation=False):
        """
        :param data_input: concept representation
        :param comm_channel: object of class CommChannel in agent.py
        :param validation: if True, take argmax(.) over logits/probs
        """
        # model code
        batch_size = data_input.size(0)
        message = []
        log_probs = torch.tensor(0.).to(self.device)

        logits = self.output_layer(data_input)

        logits = logits.view(batch_size, self.output_size, -1)
        binary_probs = torch.softmax(logits, dim=-1)
        probs = torch.zeros(batch_size, self.output_size).to(self.device)
        if not validation:
            predict, probs = comm_channel.binary(logits)
        else:
            predict = torch.max(logits, dim=2)[1].type(torch.float32).to(self.device)

        for i in range(batch_size):
            probs[i] = binary_probs[i].gather(1, predict[i].view(-1, 1).type(torch.int64)).view(-1)
        log_probs += torch.log((probs * predict).sum(dim=1)).squeeze(0)
        message.extend(predict)

        message = torch.stack(message)
        # return message, log_probs, entropy
        return message, log_probs


class RandomSpeaker:
    def __init__(self, comm_type, num_msgs, msg_len):
        pass


# =========================Target encoder Module============================= #
class AttentionDecoder(nn.Module):
    """
    identifies the target in context of the distractors
    by using the received messages + grid input obtained
    """

    def __init__(self, message_len, output_size, device):
        super().__init__()
        self.device = device
        # self.rnn_cell = nn.RNNCell(message_len, output_size)
        # self.init_input = nn.Parameter(torch.zeros(1, output_size, device=self.device), requires_grad=True)
        self.decode_message = nn.Linear(message_len, output_size)


    @staticmethod
    def attention(distractors_encoded, message_decoded):
        """
        obtain weights by taking the dot product between the target representation (using messages)
        and each cell of the grid.

        weights are added to each cell as an additional dimension
        """
        shape = distractors_encoded.shape
        weights = torch.bmm(distractors_encoded.unsqueeze(0), message_decoded.view(-1, shape[-1], 1))
        return weights

    def forward(self, speaker_out, distractors_encoded):
        # message_decoded = self.rnn_cell(speaker_out, self.init_input)
        message_decoded = self.decode_message(speaker_out)
        attention_weights = AttentionDecoder.attention(distractors_encoded, message_decoded)
        return attention_weights.squeeze(-1)


# ==========================Grid Encoder Module========================= #
class DistractorEncoder(nn.Module):
    """
    processes the latent grid representation (i.e. the output from the target encoder)
    """

    def __init__(self, input_size, output_size):
        super().__init__()
        self.in_size = input_size
        self.out_size = output_size
        self.encoder = nn.Linear(self.in_size, self.out_size)

    def forward(self, candidates):
        # batch_size = len(candidates)
        state = []
        for candidate in candidates:
            state.append(self.encoder(candidate))
        return torch.stack(state)


# ============================Listener Module=============================== #
class ListenerBot(nn.Module):
    """
    Uses the state (processed grid information from the grid encoder) for sequential decision making
    > Steps:
    1. Target Encoder processes the received messages and the current grid input
    and generates a new grid representation containing the target and task specifics
    2. Grid Encoder uses the new grid representation and convolves over each cell using 1*1 conv;
    the output of the Grid Encoder is the state
    3. Listener Action Layer uses the state to take actions
    """

    def __init__(self, msg_len, input_size, output_size, device, oracle=False):
        super().__init__()
        if not oracle:
            self.attention_encoder = AttentionDecoder(message_len=msg_len, output_size=output_size, device=device)
        self.distractor_encoder = DistractorEncoder(input_size=input_size, output_size=output_size)
        # self.action_layer = nn.Linear(5, 5)
        self.oracle = oracle

        self.input_size = input_size

    def forward(self, candidates, speaker_out):
        distractors_encoded = self.distractor_encoder(candidates)
        policy_logits = self.attention_encoder(distractors_encoded=distractors_encoded, speaker_out=speaker_out)
        # policy_logits = self.action_layer(policy_logits)
        return policy_logits


# ============================ Discriminator =============================== #
class Discriminator(nn.Module):
    def __init__(self, msg_dim):
        """
        msg_dim = dim of messages
        """
        super(Discriminator, self).__init__()
        self.input_size = msg_dim
        self.output_size = msg_dim
        self.output_layer = nn.Linear(self.input_size, self.output_size)

    def forward(self, message_concat):
        logits = self.output_layer(message_concat)
        return logits
