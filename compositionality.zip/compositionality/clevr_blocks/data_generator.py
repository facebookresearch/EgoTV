from torch.utils.data import Dataset
from torchvision import datasets, transforms
from torchvision.io import read_image
from pathlib import Path
import numpy as np
from copy import copy
import random


class ClevrBlocksData(Dataset):
    def __init__(self, root, n_distractors, num_samples, held_out, generalization=False):
        """
        Args:
            root: root path
            n_distractors: number of distractors (total images = distractors + target)
            num_samples: number of training / validation samples
            held_out: held_out set for measuring generalization
            generalization: held-out set used during training and validation
        """
        root = Path(root)
        if not (root.exists() and root.is_dir()):
            raise ValueError(f"Data root '{root}' is invalid")

        self.root = root
        self.n_distractors = n_distractors
        self.num_samples = num_samples
        self.held_out = held_out
        self.generalization = generalization
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize(32),
            transforms.CenterCrop(26),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])
        # self.transform = transforms.ToTensor()
        self._samples = self._collect_samples()

    def __getitem__(self, index):
        """Get sample by index

        Args:
            index (int)

        Returns:
            The index'th sample (target, candidate_sets, label, target_class)
        """
        target_path, candidate_set_paths, target_idx, target_class = self._samples[index]
        target = self.transform(read_image(path=target_path)[:3])
        candidate_set = [self.transform(read_image(path=file_name)[:3]) for file_name in candidate_set_paths]
        return target, candidate_set, target_idx, target_class

    def __len__(self):
        return len(self._samples)

    def _collect_samples(self):
        all_samples = []
        data = datasets.ImageFolder(self.root)
        num_classes = len(data.classes)

        for _ in range(self.num_samples):

            folder_indices = random.sample(list(np.arange(num_classes)), self.n_distractors + 1)
            folder_indices_choice = copy(folder_indices)

            if self.generalization is False:  # during training or validation
                for held_out_class in self.held_out:
                    held_out_idx = data.class_to_idx[held_out_class]
                    if held_out_idx in folder_indices_choice:
                        folder_indices_choice.remove(held_out_idx)

            target_class = data.classes[np.random.choice(folder_indices_choice)]
            target_idx = folder_indices.index(data.class_to_idx[target_class])
            candidate_set_paths = []
            for folder_index in folder_indices:
                image_index = 100 * folder_index + np.random.randint(low=0, high=100, size=1)[0]
                file_name = data.imgs[image_index][0]
                # image = read_image(path=file_name)[:3]
                candidate_set_paths.append(file_name)
            target_path = candidate_set_paths[target_idx]
            all_samples.append((target_path, candidate_set_paths, target_idx, target_class.split('_')))

        return all_samples