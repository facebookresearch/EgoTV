"""
baselines:
        Random, Fixed, Perfect, Oracle, Simple (Categorical)

"""

from gcomm.arguments import Arguments
from baseline_models import SpeakerBot, ListenerBot, Discriminator
from gcomm.agent import SpeakerAgent, ListenerAgent
from gcomm.helpers import color_to_idx, shape_to_idx, generate_task_progress, plot_metrics
from gcomm.metrics import topsim_metric, posdis_metric, bosdis_metric, posdis_metric2
from data_generator import ClevrBlocksData
# from plot import generate_task_progress

import os
import random
from pathlib import Path
import torch
import torch.nn as nn
import torch.optim as optim
from collections import namedtuple

SAVE_FIG = False  # save test episodes?
# DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
DEVICE = torch.device("cpu")
flags = Arguments()

LAMBDA = 0.01  # hyper parameter for entropy

# ======================= Data storage paths ========================== #
run_id = flags['run_id']
path = os.path.join(os.getcwd(), flags['comm_type'] + "_intrinsic_speaker_data/") + "run_" + str(run_id) + "/"
model_load_path = Path(path + "checkpoint_dir")
plot_path = Path(path + "plots")
model_load_path.mkdir(exist_ok=True, parents=True)
plot_path.mkdir(exist_ok=True, parents=True)
log_file = open(path + "log.txt", "w")
log_file.write(str(flags) + '\n')
# visualization_path = None
save_model_flag = True
# corr_pear, corr_spear, posdis_arr, bosdis_arr = [], [], [], []

# ==================Transition Memory==================== #
train_discriminator_period = 500 # 300
Transition = namedtuple('Transition', ('message_seq', 'shape_label', 'color_label'))
d_memory_size = 5000 # 5000 # 10000
d_batch_size = 100  # 400 # 100
d_batches = 10 # 10 # 5
negative_sampling_prob = 0.6
# BETA = 1.80, 2.48
LAMBDA_coverage1 = 0.05  # 0.01
LAMBDA_coverage2 = 0.  # 1.80 with DELTA 1e-2
LAMBDA_influence = 0.0005  # 0.001
# net_d_loss = []
# composition_dict = dict()

# ==================Learning Rate======================= #
lr_rest = 8e-5 # 2e-5 # 1e-3
lr_discriminator = 1e-2 # 5e-3  # 1e-2


# ==================================Replay Memory Buffer================================== #
class ReplayMemory(object):

    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.position = 0

    def push(self, *args):
        """Saves a transition"""
        if len(self.memory) < self.capacity:
            self.memory.append(None)
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def reset(self):
        """Reset the Replay Buffer"""
        self.memory = []
        self.position = 0

    def __len__(self):
        return len(self.memory)


# =================================Train Discriminator=============================== #
def train_discriminator():
    if len(d_MEMORY) < d_batch_size:
        return
    all_vars['discriminator'].train()

    print('\n----------------------Training Discriminator------------------------')
    for _ in range(d_batches):
        transitions = d_MEMORY.sample(d_batch_size)
        # Transpose the batch. Converts batch-array of Transitions to Transition of batch-arrays.
        batch = Transition(*zip(*transitions))
        input_msgs_batch = torch.stack(batch.message_seq)
        shape_batch, color_batch = torch.stack(batch.shape_label), torch.stack(batch.color_label)

        pred = all_vars['discriminator'](message_concat=input_msgs_batch)
        loss = classification_loss(pred['shape'], shape_batch.view(-1)) + \
               classification_loss(pred['color'], color_batch.view(-1))

        discriminator_optimizer.zero_grad()
        loss.backward()
        discriminator_optimizer.step()
        print('d_loss: {} \n'.format(loss.item()))
        # net_d_loss.append(loss)


# =======================Save Models======================== #
def save_models(iteration):
    for model_name, model in all_vars.items():
        if model_name in ['speaker_bot', 'listener_bot', 'discriminator']:
            with open(os.path.join(model_load_path, str(iteration) + '_' + model_name), 'wb') as f:
                torch.save(model.state_dict(), f)


def copy_models():
    list_s_dict = all_vars['listener_bot'].state_dict()
    listener_bot_local = ListenerBot(input_size=flags['input_dim'], output_size=flags['input_dim'],
                                     msg_len=flags['input_dim'], num_msgs=2, oracle=oracle,
                                     device=DEVICE).to(DEVICE)
    listener_bot_local.load_state_dict(list_s_dict)
    listener_bot_local.eval()

    speaker_bot_local = SpeakerBot(comm_type=flags['comm_type'], input_size=flags['input_dim'],
                                   hidden_size=flags['input_dim'], output_size=flags['input_dim'], num_msgs=2,
                                   device=DEVICE).to(DEVICE)
    speaker_s_dict = all_vars['speaker_bot'].state_dict()
    speaker_bot_local.load_state_dict(speaker_s_dict)
    speaker_bot_local.eval()
    return speaker_bot_local, listener_bot_local


def single_loop(data_sample, validation=False, composition_dict=None,
                posdis_composition_array=None, bosdis_composition_array=None):
    speaker_out, _ = speaker_agent.transmit(concept=data_sample[0], validation=validation)
    speaker_out = speaker_out.view(1, -1)

    if not validation:
        color_lab, shape_lab = torch.tensor(color_to_idx(data_sample[3][0]), dtype=torch.long).unsqueeze(0).to(DEVICE), \
                               torch.tensor(shape_to_idx(data_sample[3][1]), dtype=torch.long).unsqueeze(0).to(DEVICE)

        all_vars['discriminator'].eval()

        # ==================================Intrinsic Reward 1===================================== #
        with torch.no_grad():
            # TODO: see if without detach() also works
            pred = all_vars['discriminator'](message_concat=speaker_out.detach())
            d_loss = classification_loss(pred['shape'], shape_lab) + classification_loss(pred['color'], color_lab)

    # =======================Measure Composition======================== #
    if validation:
        symbols = [str(torch.argmax(speaker_out[:, :4]).item()), str(torch.argmax(speaker_out[:, 4:8]).item())]
        str_obs = tuple([str(color_to_idx(data_sample[3][0])), str(shape_to_idx(data_sample[3][1]))])
        composition_dict[str_obs] = ''.join(symbols)

        # bosdis
        if [int(x) for x in str_obs] not in bosdis_composition_array[0]:
            bosdis_composition_array[0].append([int(x) for x in str_obs])  # attributes
            # if [int(x) for x in symbols] not in bosdis_composition_array[1]:
            bosdis_composition_array[1].append([int(x) for x in symbols])  # messages

        # posdis
        str_obs = [str_obs[0], str(4 + int(str_obs[1]))]
        for symbol_index, symbol in enumerate(symbols):
            for str_ob in str_obs:
                if symbol not in posdis_composition_array[symbol_index][int(int(str_ob) // 4)].keys():
                    posdis_composition_array[symbol_index][int(int(str_ob) // 4)][symbol] = {}
                if str_ob not in posdis_composition_array[symbol_index][int(int(str_ob) // 4)][symbol].keys():
                    posdis_composition_array[symbol_index][int(int(str_ob) // 4)][symbol][str_ob] = 0
                posdis_composition_array[symbol_index][int(int(str_ob) // 4)][symbol][str_ob] += 1

    candidates = torch.stack(data_sample[1]).to(DEVICE)
    log_prob, entropy, policy_all_probs, action = listener_agent.act(state=(candidates, speaker_out),
                                                                     validate=validation)

    # ==================================Intrinsic Reward 2===================================== #
    # if not validation:
    #     influence_rewards = 0.
    #     MC_batch_size = 10
    #
    #     with torch.no_grad():
    #         # speaker_, listener_ = copy_models()
    #         P_probs = policy_all_probs.detach() + 1e-8  # here P is a function of both msg, grid
    #         Q_probs = torch.zeros(1, flags['num_distractors'] + 1).to(DEVICE)  # here Q is a function of only grid
    #
    #         for _ in range(MC_batch_size):
    #             msg_sample, msg_log_prob_sample = speaker_bot(data_input=
    #             data_sample[0].detach().unsqueeze(0).type(torch.float32).to(
    #                 DEVICE),
    #                 comm_channel=speaker_agent.comm,
    #                 validation=validation)
    #             msg_sample = msg_sample.view(1, -1)
    #             Q_probs_conditional = torch.softmax(listener_bot(candidates=candidates, speaker_out=msg_sample,
    #                                                           comm_channel=listener_agent.comm, validation=validation),
    #                                                 dim=-1) + 1e-8
    #             Q_probs += Q_probs_conditional * torch.exp(msg_log_prob_sample)
    #         Q_probs = torch.softmax(Q_probs, dim=-1)
    #         influence_rewards += LAMBDA_influence * (P_probs * (P_probs / Q_probs).log()).mean()

    if action == data_sample[2]:
        reward = torch.tensor(1.).to(DEVICE)
    else:
        reward = torch.tensor(0.).to(DEVICE)

    if not validation:
        if reward >= 1.0:
            d_MEMORY.push(speaker_out.detach().squeeze(0), shape_lab, color_lab)
        elif reward < 1.0 and random.random() > negative_sampling_prob:
            d_MEMORY.push(speaker_out.detach().squeeze(0), shape_lab, color_lab)

    if validation:
        return reward, posdis_composition_array, bosdis_composition_array

    # reward += torch.tensor(LAMBDA_coverage1 * (- d_loss.item())).to(DEVICE) \
    #           + influence_rewards.detach().to(DEVICE)
    reward += torch.tensor(LAMBDA_coverage1 * (- d_loss.item())).to(DEVICE)
    agent_loss = -log_prob * reward.detach()
    net_loss = agent_loss - LAMBDA * entropy
    return net_loss, reward


def main():
    # Create directory for visualizations if it doesn't exist.
    flags['output_directory'] = os.path.join(os.getcwd(), flags['output_directory'])
    if flags['output_directory']:
        visualization_path = flags['output_directory']
        if not os.path.exists(visualization_path):
            os.mkdir(visualization_path)

    # generating episodes
    task_rewards = {"'walk'": []}

    train_data = ClevrBlocksData(root=flags['dataset_directory'], n_distractors=flags['num_distractors'],
                                 num_samples=flags["num_episodes"], held_out=['red_sphere'])

    num_val_iter = 50  # number of validation loops/episodes to be run
    test_data = ClevrBlocksData(root=flags['dataset_directory'], n_distractors=flags['num_distractors'],
                                num_samples=num_val_iter, held_out=['red_sphere'])

    for Episode_count in range(1, flags["num_episodes"] + 1):
        # ==================== Train =================== #
        if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
            all_vars['speaker_bot'].train(True)
        all_vars['listener_bot'].train(True)
        all_vars['optimizer'].zero_grad()
        # run a single training loop
        net_loss, train_rewards = single_loop(train_data[Episode_count - 1], validation=False)
        net_loss.backward()
        all_vars['optimizer'].step()

        # ==================== validation ====================== #
        if Episode_count % 50 == 0:
            val_rewards = 0
            if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
                all_vars['speaker_bot'].eval()
            all_vars['listener_bot'].eval()
            composition_dict = dict()
            posdis_composition_array = [[dict() for _ in range(2)] for _ in
                                        range(2)]  # O num_msgs=2, I num_attributes=2
            bosdis_composition_array = [[], []]  # attribute arr, message_arr
            with torch.no_grad():
                for val_iter in range(num_val_iter):
                    val_reward, posdis_composition_array, bosdis_composition_array = \
                        single_loop(test_data[val_iter],
                                    composition_dict=composition_dict,
                                    posdis_composition_array=posdis_composition_array,
                                    bosdis_composition_array=bosdis_composition_array,
                                    validation=True)
                    val_rewards += val_reward / num_val_iter
            # print('episode: {} | val-reward: {}'.format(Episode_count, val_rewards))
            # task_rewards["'walk'"].extend([val_rewards])
            # =================Measure correlation================== #
            c_p, c_s = topsim_metric(composition_dict)
            # corr_pear.extend([c_p])
            # corr_spear.extend([c_s])
            posdis = posdis_metric(posdis_composition_array)
            posdis2 = posdis_metric2(attributes=torch.tensor(bosdis_composition_array[0]),
                                     messages=torch.tensor(bosdis_composition_array[1]))
            # posdis_arr.extend([max(posdis, posdis2)])
            bosdis = bosdis_metric(attributes=torch.tensor(bosdis_composition_array[0]),
                                   messages=torch.tensor(bosdis_composition_array[1]),
                                   vocab_size=4)
            # bosdis_arr.extend([bosdis])
            print('episode: {} | val-reward: {} | topsim: {} | posdis: {} | bosdis: {}'.format(Episode_count,
                                                                                               val_rewards, c_p,
                                                                                               max(posdis, posdis2),
                                                                                               bosdis))
            log_file.write('Episode: ' + str(Episode_count) + ' | Train Reward: ' + str(train_rewards.sum().item()) +
                           ' | Val Reward: ' + str(val_rewards.mean().item()) + ' | Train Loss: ' + str(net_loss.item()) +
                           ' | topsim (Pearson): ' + str(c_p) + ' | topsim (Spearman): ' + str(c_s) +
                           ' | posdis: ' + str(posdis) + '/' + str(posdis2) + ' | bosdis: ' + str(bosdis) + "\n")

        # ========================== Plot ============================= #
        if Episode_count % 2000 == 0 and Episode_count != 0:
            # print('------------------Generating plots------------------------')
            # generate_task_progress(task_reward_dict=task_rewards, color='m',
            #                        file_name=os.path.join(plot_path, 'task_progress.png'))
            # plot_metrics(corr_pear, corr_spear, posdis_arr, bosdis_arr,
            #              file_name=os.path.join(plot_path, 'compositionality.png'))
            print(composition_dict)

        if Episode_count % train_discriminator_period == 0:
            # ======================training discriminator==================== #
            train_discriminator()

        # =====================save model====================== #
        if save_model_flag is True and Episode_count % 10000 == 0:
                print('------------------Saving model checkpoint------------------\n')
                save_models(iteration=Episode_count)

        log_file.flush()


if __name__ == "__main__":
    # =================initialize model params and environment============== #

    # ================== Listener-Bot ====================== #
    oracle = True if flags['comm_type'] == 'oracle' else False
    listener_bot = ListenerBot(input_size=flags['input_dim'], output_size=flags['input_dim'],
                               msg_len=flags['input_dim'], num_msgs=2, oracle=oracle,
                               device=DEVICE).to(DEVICE)
    listener_agent = ListenerAgent(listener_model=listener_bot)

    # ================== Speaker-Bot ====================== #
    speaker_bot = SpeakerBot(comm_type=flags['comm_type'], input_size=flags['input_dim'],
                             hidden_size=flags['input_dim'],
                             output_size=flags['input_dim'], num_msgs=2, device=DEVICE).to(DEVICE)
    speaker_agent = SpeakerAgent(num_msgs=1, msg_len=flags['input_dim'], comm_type=flags['comm_type'],
                                 temp=flags['temp'], speaker_model=speaker_bot, device=DEVICE)

    # ================== Discriminator ===================== #
    discriminator = Discriminator(msg_dim=flags['input_dim'], num_msgs=2).to(DEVICE)
    discriminator_optimizer = optim.Adam(discriminator.parameters(), lr=lr_discriminator)
    classification_loss = nn.CrossEntropyLoss()
    d_MEMORY = ReplayMemory(d_memory_size)

    all_params = list(listener_agent.listener_model.parameters())
    if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
        all_params += list(speaker_agent.speaker_model.parameters())

    optimizer = optim.AdamW(all_params, lr=lr_rest)
    all_vars = {'listener_bot': listener_bot, 'speaker_bot': speaker_bot, 'optimizer': optimizer,
                'discriminator': discriminator, 'discriminator_optimizer': discriminator_optimizer}

    print('\n=================== Intrinsic [CLEVR Blocks]: {} ===================\n'.format(flags['comm_type'].upper()))
    main()

    log_file.close()
