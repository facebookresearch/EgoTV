import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.relaxed_categorical import RelaxedOneHotCategorical, Categorical

# ========================Speaker Module============================ #
class SpeakerBot(nn.Module):
    """
    Speaker has access to the 18-d concept input (size + shape + color + weight + task)
    and transmits 'num_msgs' (n_m) messages of length 'msg_len' (d_m)
    """

    def __init__(self, comm_type, input_size, hidden_size, output_size, num_msgs, device):
        """
        :comm_type: ['categorical', 'binary', 'continuous']
        :input size: 18-d (concept representation)
        :hidden_size: hidden size of RNN
        :output_size: msg_len (d_m)
        :num_msgs: num_msgs (n_m)
        :device: cpu/gpu
        """
        super().__init__()
        # model params
        self.comm_type = comm_type
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size  # msg_len
        self.num_msgs = num_msgs
        self.device = device

        self.image_enc_1 = nn.Sequential(nn.Conv2d(in_channels=3,
                                                   out_channels=1,
                                                   kernel_size=(4, 4),
                                                   stride=(2, 2)),
                                         nn.MaxPool2d(2),
                                         nn.Dropout(0.5),
                                         nn.ReLU(),
                                         nn.Conv2d(in_channels=1,
                                                   out_channels=1,
                                                   kernel_size=(4, 4),
                                                   stride=(2, 2)))
        self.image_enc_2 = nn.Sequential(nn.Conv2d(in_channels=3,
                                                   out_channels=1,
                                                   kernel_size=(4, 4),
                                                   stride=(2, 2)),
                                         nn.MaxPool2d(2),
                                         nn.Dropout(0.5),
                                         nn.ReLU(),
                                         nn.Conv2d(in_channels=1,
                                                   out_channels=1,
                                                   kernel_size=(4, 4),
                                                   stride=(2, 2)))

        # self.image_enc_1 = nn.Sequential(nn.Conv2d(in_channels=3,
        #                                        out_channels=1,
        #                                        kernel_size=(7, 7),
        #                                        stride=(3, 3)),
        #                              nn.MaxPool2d(2),
        #                              nn.Dropout(0.2),
        #                              nn.ReLU(),
        #                              nn.Conv2d(in_channels=1,
        #                                        out_channels=1,
        #                                        kernel_size=(4, 4),
        #                                        stride=(2, 2)),
        #                              nn.MaxPool2d(2))
        #
        # self.image_enc_2 = nn.Sequential(nn.Conv2d(in_channels=3,
        #                                            out_channels=1,
        #                                            kernel_size=(7, 7),
        #                                            stride=(3, 3)),
        #                                  nn.MaxPool2d(2),
        #                                  nn.Dropout(0.2),
        #                                  nn.ReLU(),
        #                                  nn.Conv2d(in_channels=1,
        #                                            out_channels=1,
        #                                            kernel_size=(4, 4),
        #                                            stride=(2, 2)),
        #                                  nn.MaxPool2d(2))
        self.image_enc = [self.image_enc_1, self.image_enc_2]

        self.rnn_cell = nn.RNNCell(self.input_size, self.hidden_size)
        # self.output_layer = nn.Linear(self.hidden_size, self.output_size)
        self.init_input = nn.Parameter(torch.zeros(1, self.hidden_size, device=self.device), requires_grad=True)

    def forward(self, data_input, comm_channel, validation=False):
        """
        :param data_input: concept representation
        :param comm_channel: object of class CommChannel in agent.py
        :param validation: if True, take argmax(.) over logits/probs
        """
        # model code
        batch_size = data_input.size(0)
        decoder_hidden = self.init_input
        messages = []
        # entropy = torch.zeros((batch_size,)).to(self.device)
        log_probs = torch.tensor(0.).to(self.device)

        # image_enc = self.image_enc(data_input).reshape(batch_size, -1)
        for ind in range(self.num_msgs):
            image_enc = self.image_enc[ind](data_input).reshape(batch_size, -1)
            decoder_hidden = self.rnn_cell(image_enc, decoder_hidden)
            # logits = self.output_layer(image_enc)
            probs = F.softmax(image_enc, dim=-1)

            if not validation:
                predict, _ = comm_channel.one_hot(probs)
            else:
                predict = F.one_hot(torch.argmax(probs, dim=1), num_classes=self.output_size).float()

            log_probs += torch.log((probs * predict).sum(dim=1)).squeeze(0)
            messages.extend(predict)
            # decoder_hidden = predict.detach()

        messages = torch.stack(messages)
        # return message, log_probs, entropy
        return messages, log_probs


class RandomSpeaker:
    def __init__(self, comm_type, num_msgs, msg_len):
        pass


# =========================Target encoder Module============================= #
class AttentionDecoder(nn.Module):
    """
    identifies the target in context of the distractors
    by using the received messages + grid input obtained
    """

    def __init__(self, num_msgs, message_len, output_size, device):
        super().__init__()
        self.device = device
        self.message_decoder = nn.Linear(num_msgs * message_len, output_size)

    @staticmethod
    def attention(distractors_encoded, message_decoded):
        """
        obtain weights by taking the dot product between the target representation (using messages)
        and each cell of the grid.

        weights are added to each cell as an additional dimension
        """
        shape = distractors_encoded.shape
        weights = torch.bmm(distractors_encoded.view(1, -1, shape[-1]), message_decoded.view(-1, shape[-1], 1))
        return weights

    def forward(self, speaker_out, distractors_encoded):
        # message_decoded = self.message_decoder(speaker_out)
        attention_weights = AttentionDecoder.attention(distractors_encoded, speaker_out)
        return attention_weights.squeeze(-1)


# ==========================Grid Encoder Module========================= #
class DistractorEncoder(nn.Module):
    """
    processes the latent grid representation (i.e. the output from the target encoder)
    """

    def __init__(self, input_size, output_size):
        super().__init__()
        self.in_size = input_size
        self.out_size = output_size
        self.image_enc_1 = nn.Sequential(nn.Conv2d(in_channels=3,
                                                   out_channels=1,
                                                   kernel_size=(4, 4),
                                                   stride=(2, 2)),
                                         nn.MaxPool2d(2),
                                         nn.Dropout(0.5),
                                         nn.ReLU(),
                                         nn.Conv2d(in_channels=1,
                                                   out_channels=1,
                                                   kernel_size=(4, 4),
                                                   stride=(2, 2)))
        self.image_enc_2 = nn.Sequential(nn.Conv2d(in_channels=3,
                                                   out_channels=1,
                                                   kernel_size=(4, 4),
                                                   stride=(2, 2)),
                                         nn.MaxPool2d(2),
                                         nn.Dropout(0.5),
                                         nn.ReLU(),
                                         nn.Conv2d(in_channels=1,
                                                   out_channels=1,
                                                   kernel_size=(4, 4),
                                                   stride=(2, 2)))

        # self.image_enc_1 = nn.Sequential(nn.Conv2d(in_channels=3,
        #                                            out_channels=1,
        #                                            kernel_size=(7, 7),
        #                                            stride=(3, 3)),
        #                                  nn.MaxPool2d(2),
        #                                  nn.Dropout(0.2),
        #                                  nn.ReLU(),
        #                                  nn.Conv2d(in_channels=1,
        #                                            out_channels=1,
        #                                            kernel_size=(4, 4),
        #                                            stride=(2, 2)),
        #                                  nn.MaxPool2d(2))
        #
        # self.image_enc_2 = nn.Sequential(nn.Conv2d(in_channels=3,
        #                                            out_channels=1,
        #                                            kernel_size=(7, 7),
        #                                            stride=(3, 3)),
        #                                  nn.MaxPool2d(2),
        #                                  nn.Dropout(0.2),
        #                                  nn.ReLU(),
        #                                  nn.Conv2d(in_channels=1,
        #                                            out_channels=1,
        #                                            kernel_size=(4, 4),
        #                                            stride=(2, 2)),
        #                                  nn.MaxPool2d(2))
        # self.image_enc = [self.image_enc_1, self.image_enc_2]

    def forward(self, candidates, comm_channel, validation=False):
            state = []
            for candidate in candidates:
                candidate = candidate.detach().unsqueeze(0).type(torch.float32)
                enc1 = self.image_enc_1(candidate).reshape(1, -1)
                if not validation:
                    predict1, _ = comm_channel.one_hot(torch.softmax(enc1, dim=-1))
                else:
                    predict1 = F.one_hot(torch.argmax(torch.softmax(enc1, dim=-1), dim=1), num_classes=4).float()

                enc2 = self.image_enc_2(candidate).reshape(1, -1)
                if not validation:
                    predict2, _ = comm_channel.one_hot(torch.softmax(enc2, dim=-1))
                else:
                    predict2 = F.one_hot(torch.argmax(torch.softmax(enc2, dim=-1), dim=1), num_classes=4).float()

                # state.append(self.encoder(candidate).reshape(1, -1))
                state.append(torch.cat((predict1, predict2), dim=-1))
            return torch.stack(state)


# ============================Listener Module=============================== #
class ListenerBot(nn.Module):
    """
    Uses the state (processed grid information from the grid encoder) for sequential decision making
    > Steps:
    1. Target Encoder processes the received messages and the current grid input
    and generates a new grid representation containing the target and task specifics
    2. Grid Encoder uses the new grid representation and convolves over each cell using 1*1 conv;
    the output of the Grid Encoder is the state
    3. Listener Action Layer uses the state to take actions
    """

    def __init__(self, num_msgs, msg_len, input_size, output_size, device, oracle=False):
        super().__init__()
        if not oracle:
            self.attention_encoder = AttentionDecoder(num_msgs=num_msgs, message_len=msg_len,
                                                      output_size=output_size, device=device)
        self.distractor_encoder = DistractorEncoder(input_size=input_size, output_size=output_size)
        self.oracle = oracle

        # self.input_size = input_size
        # self.num_actions = num_actions

    def forward(self, candidates, speaker_out, comm_channel, validation):
        distractors_encoded = self.distractor_encoder(candidates, comm_channel, validation)
        policy_logits = self.attention_encoder(distractors_encoded=distractors_encoded, speaker_out=speaker_out)
        # policy_logits = self.action_layer(state)
        return policy_logits


# ============================ Discriminator =============================== #
class Discriminator(nn.Module):
    def __init__(self, num_msgs, msg_dim):
        """
        msg_dim = dim of messages
        """
        super(Discriminator, self).__init__()
        self.msg_dim = msg_dim
        self.fc1 = nn.Sequential(nn.Linear(num_msgs * self.msg_dim, 4),
                                 nn.ReLU(),
                                 nn.Linear(4, 4))  # shape
        self.fc2 =  nn.Sequential(nn.Linear(num_msgs * self.msg_dim, 4),
                                 nn.ReLU(),
                                 nn.Linear(4, 4))  # color

    def forward(self, message_concat):
        shape_dist, color_dist = self.fc1(message_concat), self.fc2(message_concat)
        return {'shape': shape_dist, 'color': color_dist}
