import numpy as np
import torch
from typing import List
import matplotlib.pyplot as plt


def topo_sort(items, constraints):
    if not constraints:
        return items
    items = list(items)
    constraints = list(constraints)
    out = []
    while len(items) > 0:
        roots = [
            i for i in items
            if not any(c[1] == i for c in constraints)
        ]
        assert len(roots) > 0, (items, constraints)
        to_pop = roots[0]
        items.remove(to_pop)
        constraints = [c for c in constraints if c[0] != to_pop]
        out.append(to_pop)
    return out


def color_to_idx(index):
    color_dict = {'red': 0, 'blue': 1, 'yellow': 2, 'green': 3}
    return color_dict[index]


def shape_to_idx(index):
    shape_dict = {'cube': 0, 'sphere': 1, 'cone': 2, 'cylinder': 3}
    return shape_dict[index]


def one_hot(size: int, idx: int) -> np.ndarray:
    one_hot_vector = np.zeros(size, dtype=int)
    one_hot_vector[idx] = 1
    return one_hot_vector


def generate_possible_object_names(color: str, shape: str) -> List[str]:
    # TODO: does this still make sense when size is not small or large
    names = [shape, ' '.join([color, shape])]
    return names


def generate_task_progress(task_reward_dict, color, file_name=None):
    fig = plt.figure()
    for task, rewards in task_reward_dict.items():
        acl_iter = np.arange(len(rewards))
        plt.plot(acl_iter, rewards, label=task)
    plt.legend()
    plt.title('Task Rewards (Validation)')
    if file_name is None:
        plt.savefig('tasks_progress.png')
    else:
        plt.savefig(file_name)
    plt.close(fig)


def generate_task_frequency(task_freq_dict, file_name=None):
    fig = plt.figure()
    tasks = list(task_freq_dict.keys())
    freq = list(task_freq_dict.values())
    plt.bar(tasks, freq)
    plt.title('Task Frequency')
    if file_name is None:
        plt.savefig('tasks_frequency.png')
    else:
        plt.savefig(file_name)
    plt.close(fig)


def generate_actions_frequency(action_freq_dict, file_name=None):
    fig = plt.figure()
    actions = list(action_freq_dict.keys())
    freq = list(action_freq_dict.values())
    plt.bar(actions, freq, color='g')
    plt.title('Action Frequency')
    if file_name is None:
        plt.savefig('actions_frequency.png')
    else:
        plt.savefig(file_name)
    plt.close(fig)


def plot_metrics(pearson, spearman, posdis, bosdis, file_name=None):
    fig = plt.figure()
    x = np.arange(len(pearson))
    for metric_name, metric_val in zip(['topsim', 'posdis', 'bosdis'], [pearson, posdis, bosdis]):
        plt.plot(x, metric_val, label=metric_name)
    plt.legend()
    plt.title('compositionality metric')
    if file_name is None:
        plt.savefig('compositionality.png')
    else:
        plt.savefig(file_name)
    plt.close(fig)


def entropy_dict(freq_table):
    """
    >>> d = {'a': 1, 'b': 1}
    >>> np.allclose(entropy_dict(d), 1.0)
    True
    >>> d = {'a': 1, 'b': 0}
    >>> np.allclose(entropy_dict(d), 0.0, rtol=1e-5, atol=1e-5)
    True
    """
    t = torch.tensor([v for v in freq_table.values()]).float()
    if (t < 0.0).any():
        raise RuntimeError("Encountered negative probabilities")

    t /= t.sum()
    return -(torch.where(t > 0, t.log(), t) * t).sum().item() / np.log(2)


def _hashable_tensor(t):
    if torch.is_tensor(t) and t.numel() > 1:
        t = tuple(t.tolist())
    elif torch.is_tensor(t) and t.numel() == 1:
        t = t.item()
    return t


def plot_d_loss_progress(net_d_loss, file_name=None):
    fig = plt.figure()
    x = np.arange(len(net_d_loss))
    plt.plot(x, net_d_loss, label='d loss')
    plt.legend()
    plt.title('Discriminator Loss (Train)')
    if file_name is None:
        plt.savefig('d_loss_progress.png')
    else:
        plt.savefig(file_name)
    plt.close(fig)


def plot_influence_rewards(influence_rewards, file_name=None):
    fig = plt.figure()
    x = np.arange(len(influence_rewards))
    plt.plot(x, influence_rewards, label='influence-rewards')
    plt.legend()
    plt.title('Speaker Abadoning Rewards')
    if file_name is None:
        plt.savefig('influence_rewards.png')
    else:
        plt.savefig(file_name)
    plt.close(fig)


def binary2dec(msg_seq):
    """
    receives a seq of messages [seq_len, msg_dim].
    Processes the bits (of each message )into a string.
    Converts the string from binary to decimal.
    Concatenates the decimal output of all messages (of the seq)
    """
    concat = ''
    for msg in msg_seq:
        string = ''.join([str(int(i)) for i in msg])
        concat += str(int(string, 2))
    return concat


def display_table(messages: dict, protocol: str, corr: tuple):
    print('\n ============ protocol: {} ============='.format(protocol))
    print("{:<15} {:<10}".format('Concept', 'Messages'))
    for k, v in messages.items():
        print("{:<15} {:<10}".format(' '.join(k), v))
    print("pearson_corr = {} , spearman_corr = {}".format(corr[0], corr[1]))
