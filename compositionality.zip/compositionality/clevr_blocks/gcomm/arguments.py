import argparse


def Arguments():
    parser = argparse.ArgumentParser(description="gComm")

    # ------------------------------- General arguments ------------------------------- #
    parser.add_argument('--dataset_directory', type=str, default='images/', help='root directory for images')
    parser.add_argument('--output_directory', type=str, default='save_folder', help='save episodes')

    # ------------------------------- Environment arguments ------------------------------- #

    parser.add_argument('--num_distractors', type=int, default=4, help='number of distractors')
    parser.add_argument('--input_dim', type=int, default=4, help='input dimension after encoding image')

    # ------------------------------------ RL-framework ----------------------------------------- #

    parser.add_argument('--num_episodes', type=int, default=400001, help='number of episodes', required=False)
    parser.add_argument('--episode_len', type=int, default=1, help='length of episode', required=False)
    parser.add_argument('--enable_intrinsic', action='store_true', default=True, help='enables intrinsic rewards')

    # ------------------------------------ Communication Channel ----------------------------------------- #
    parser.add_argument('--comm_type', type=str, default='random',
                        choices=['continuous', 'binary', 'categorical', 'random', 'fixed', 'perfect', 'oracle'])
    parser.add_argument('--comm_setting', type=str, default='cheap_talk',
                        choices=['cheap_talk', 'costly_signalling'], help='TODO: costly signalling')
    parser.add_argument('--temp', type=float, default=1, help='temperature parameter for discrete messages')

    # ----------------------------------- visualisation ----------------------------------------------- #
    parser.add_argument('--render_episode', action='store_true', default=False, help='whether to render every step')
    parser.add_argument('--wait_time', type=float, default=0.3, help='wait time between consecutive time-steps')

    # ----------------------------------- extra ------------------------------------------- #
    parser.add_argument('--run_id', type=int, required=False, default=201, help='run-id for saving checkpoints & plots')

    return vars(parser.parse_args())


def pass_arguments():
    flags = Arguments()
    return flags
