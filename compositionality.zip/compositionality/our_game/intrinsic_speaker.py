"""
baselines:
        Random, Fixed, Perfect, Oracle, Simple (Categorical)
Actions:
        left = 0
        right = 1
        forward = 2
        backward = 3
        push = 4
        pull = 5
        pickup = 6
        drop = 7
"""

from gComm.arguments import Arguments
from gComm.gComm_env import gCommEnv
from baseline_models import *
from gComm.agent import *
from gComm.helpers import *
from gComm.metrics import *

import os
import random
from pathlib import Path
import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
from collections import namedtuple

SAVE_FIG = False  # save test episodes?
# torch.device("cuda" if torch.cuda.is_available() else "cpu")
DEVICE = torch.device("cpu")
flags = Arguments()

GAMMA = 0.9  # discount rate
LAMBDA = 0.01  # hyper parameter for entropy
num_msgs = 3  # n_m of the communication channel
# d_m of the communication channel
if flags['comm_type'] == 'binary':
    msg_len = 2  # (binary)
else:
    msg_len = 4  # (categorical or others)

# number of actions by Listener-Bot
num_actions = 4
if flags['type_grammar'] == 'simple_trans':
    num_actions += len(flags['transitive_verbs'].split(','))

# ==================Transition Memory==================== #
train_discriminator_period = 200  # 300
if flags['type_grammar'] == 'simple_intrans':
    Transition = namedtuple('Transition', ('message_seq', 'shape_label', 'color_label'))
else:
    Transition = namedtuple('Transition', ('message_seq', 'shape_label', 'color_label', 'task_label'))
d_memory_size = 5000
d_batch_size = 400
d_batches = 10
negative_sampling_prob = 0.6
# BETA = 1.80, 2.48
LAMBDA_coverage = 0.1  # 0.01, 0.05
LAMBDA_influence = 0.1  # 0.001

# ==================Learning Rate======================= #
lr_rest = 1e-3
lr_discriminator = 1e-3

# ======================= Data storage paths ========================== #
run_id = flags['run_id']

if flags['type_grammar'] == 'simple_intrans':
    path = os.path.join(os.getcwd(), 'intrinsic' + "_speaker_data/") + "run_" + str(run_id) + "/"
else:
    path = os.path.join(os.getcwd(), 'intrinsic' + "_" + str(flags["transitive_verbs"].split(',')[0])
                        + "_speaker_data/") + "run_" + str(run_id) + "/"

model_load_path = Path(path + "checkpoint_dir")
plot_path = Path(path + "plots")
model_load_path.mkdir(exist_ok=True, parents=True)
plot_path.mkdir(exist_ok=True, parents=True)
log_file = open(path + "log.txt", "w")
log_file.write('lr_rest: ' + str(lr_rest) + ' | lr_discriminator: ' + str(lr_discriminator) +
               ' | LAMBDA_coverage: ' + str(LAMBDA_coverage) +
               ' | LAMBDA_influence: ' + str(LAMBDA_influence) + ' | d_batch_size: ' + str(d_batch_size) +
               ' | d_memory_size: ' + str(d_memory_size) + ' | d_batches: ' + str(d_batches) +
               ' | d_train_period: ' + str(train_discriminator_period) + '\n\n')
log_file.write(str(flags) + '\n')
visualization_path = None
save_model_flag = True
# corr_pear, corr_spear, posdis_arr, bosdis_arr = [], [], [], []
# net_d_loss = []
# composition_dict = dict()
# composition_array = [dict()]*num_msgs
# influence = []
EXPERIMENT = "visual"


# ==================================Replay Memory Buffer================================== #
class ReplayMemory(object):

    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.position = 0

    def push(self, *args):
        """Saves a transition"""
        if len(self.memory) < self.capacity:
            self.memory.append(None)
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def reset(self):
        """Reset the Replay Buffer"""
        self.memory = []
        self.position = 0

    def __len__(self):
        return len(self.memory)


# =================================Train Discriminator=============================== #
def train_discriminator():
    """
    {'color': pred_color, 'shape': pred_shape}
    true: speaker observation minus task encoding
    [  _      _        _       _     _ _ _ _ ]
     square cylinder circle diamond  r b y g
     ______________________________  _______
                   shape              color
    """
    if len(d_MEMORY) < d_batch_size:
        return
    all_vars['discriminator'].train(True)

    print('\n----------------------Training Discriminator------------------------')
    for _ in range(d_batches):
        transitions = d_MEMORY.sample(d_batch_size)
        # Transpose the batch. Converts batch-array of Transitions to Transition of batch-arrays.
        batch = Transition(*zip(*transitions))
        input_msgs_batch = torch.stack(batch.message_seq)
        shape_batch, color_batch = torch.stack(batch.shape_label), torch.stack(batch.color_label)
        if flags['type_grammar'] == 'simple_trans':
            task_batch = torch.stack(batch.task_label)

        pred = all_vars['discriminator'](message_concat=input_msgs_batch)

        loss = classification_loss(pred['shape'], shape_batch.view(-1)) + \
               classification_loss(pred['color'], color_batch.view(-1))
        if flags['type_grammar'] == 'simple_trans':
            loss += classification_loss(pred['task'], task_batch.view(-1))

        discriminator_optimizer.zero_grad()
        loss.backward()
        discriminator_optimizer.step()
        print('d_loss: {} \n'.format(loss.item()))
        # net_d_loss.append(loss.item())


# =======================Save Models======================== #
def save_models(iteration):
    for model_name, model in all_vars.items():
        if model_name in ['speaker_bot', 'listener_bot']:
            with open(os.path.join(model_load_path, str(iteration) + '_' + model_name), 'wb') as f:
                torch.save(model.state_dict(), f)


def copy_models():
    # s_dict = all_vars['discriminator'].state_dict()
    # # ================== Discriminator ===================== #
    # disc_copy = Discriminator(num_msgs=num_msgs, msg_dim=4).to(DEVICE)
    # disc_copy.load_state_dict(s_dict)
    # disc_copy.eval()

    list_s_dict = all_vars['listener_bot'].state_dict()
    listener_bot_local = ListenerBot(grid_size=flags['grid_size'], num_msgs=num_msgs, msg_len=msg_len,
                                     in_channels=18, out_channels=20, input_dim=320, hidden_dim1=150,
                                     hidden_dim2=30, num_actions=num_actions, oracle=oracle).to(DEVICE)
    listener_bot_local.load_state_dict(list_s_dict)
    listener_bot_local.eval()
    # listener_agent_local = ListenerAgent(listener_model=listener_bot_local)

    # ================== Speaker-Bot ====================== #
    speaker_bot_local = SpeakerBot(comm_type=flags['comm_type'], input_size=12, hidden_size=hidden_size,
                                   output_size=msg_len, num_msgs=num_msgs, device=DEVICE).to(DEVICE)
    speaker_s_dict = all_vars['speaker_bot'].state_dict()
    speaker_bot_local.load_state_dict(speaker_s_dict)
    speaker_bot_local.eval()
    # speaker_agent_local = SpeakerAgent(num_msgs=num_msgs, msg_len=msg_len, comm_type=flags['comm_type'],
    #                              temp=flags['temp'], speaker_model=speaker_bot_local, device=DEVICE)

    return speaker_bot_local, listener_bot_local


def single_loop(env, validation=False, composition_dict=None,
                posdis_composition_array=None, bosdis_composition_array=None):
    # EXPERIMENT == 'visual':
    while True:
        instruction, verb_in_command = env.generate_world(
            other_objects_sample_percentage=flags['other_objects_sample_percentage'],
            max_other_objects=flags['max_objects'],
            min_other_objects=flags['min_other_objects'],
            num_obstacles=flags['num_obstacles'])
        # if validation and EXPERIMENT in env._world_type:
        #     break
        if validation:
            break
        if not validation and EXPERIMENT not in env._world_type:
            break

    # concept input (encoded instruction and target information)
    concept_representation, weight = env.concept_input(verb_in_command)

    actions = ''
    log_probs = []
    rewards = []
    influence_rewards = []
    entropy_term = torch.tensor(0.).to(DEVICE)

    # speaker model processes instruction based on baseline specification
    speaker_out, msg_log_prob = speaker_agent.transmit(concept=concept_representation, validation=validation)
    speaker_out = speaker_out.view(1, -1)

    # =======================Measure Composition======================== #
    if validation:
        symbols = [str(torch.argmax(speaker_out[:, :4]).item()), str(torch.argmax(speaker_out[:, 4:8]).item()),
                   str(torch.argmax(speaker_out[:, 8:12]).item())]
        str_obs = tuple([str(torch.argmax(torch.tensor(concept_representation)[4:8]).item()),
                         str(torch.argmax(torch.tensor(concept_representation)[8:12]).item()),
                         str(torch.argmax(torch.tensor(concept_representation)[-4:]).item())])
        composition_dict[str_obs] = ''.join(symbols)

        # bosdis
        if [int(x) for x in str_obs] not in bosdis_composition_array[0]:
            bosdis_composition_array[0].append([int(x) for x in str_obs])  # attributes
            # if [int(x) for x in symbols] not in bosdis_composition_array[1]:
            bosdis_composition_array[1].append([int(x) for x in symbols])  # messages

        # posdis, bosdis
        str_obs = [str_obs[0], str(4 + int(str_obs[1])), str(8 + int(str_obs[2]))]
        for symbol_index, symbol in enumerate(symbols):
            for str_ob in str_obs:
                if symbol not in posdis_composition_array[symbol_index][int(int(str_ob) // 4)].keys():
                    posdis_composition_array[symbol_index][int(int(str_ob) // 4)][symbol] = {}
                if str_ob not in posdis_composition_array[symbol_index][int(int(str_ob) // 4)][symbol].keys():
                    posdis_composition_array[symbol_index][int(int(str_ob) // 4)][symbol][str_ob] = 0
                posdis_composition_array[symbol_index][int(int(str_ob) // 4)][symbol][str_ob] += 1

    # ==================================Intrinsic Reward 1===================================== #
    if not validation:
        task_lab, shape_lab, color_lab = \
            torch.argmax(torch.tensor(concept_representation, device=DEVICE)[-4:]).view(-1), \
            torch.argmax(torch.tensor(concept_representation, device=DEVICE)[4:8]).view(-1), \
            torch.argmax(torch.tensor(concept_representation, device=DEVICE)[8:12]).view(-1)
        # d_MEMORY.push(speaker_out.detach().squeeze(0), shape_lab, color_lab)
        all_vars['discriminator'].eval()

        # ========================Discriminator rewards======================== #
        with torch.no_grad():
            pred = all_vars['discriminator'](message_concat=speaker_out.detach())
            d_loss = classification_loss(pred['shape'], shape_lab) + \
                     classification_loss(pred['color'], color_lab)
            if flags['type_grammar'] == 'simple_trans':
                d_loss += classification_loss(pred['task'], task_lab)

    # time-steps
    for t in range(flags["episode_len"]):
        # grid input
        if flags["grid_input_type"] == "image":
            grid_representation = env.grid_image_input()  # [img_height, img_width, 3]
        elif flags["grid_input_type"] == "vector":
            grid_vector_size = 17
            grid_representation = env.grid_input()  # [grid_height, grid_width, num_channels]
            grid_representation = torch.tensor(grid_representation,
                                               dtype=torch.float32).contiguous().view(1,
                                                                                      flags["grid_size"] ** 2,
                                                                                      grid_vector_size).to(DEVICE)
        # baseline: ORACLE LISTENER
        elif flags["grid_input_type"] == "with_target":
            grid_representation = \
                env.grid_input(specify_target=True)  # [grid_height, grid_width, num_channels+1]
            grid_vector_size = 18
            grid_representation = torch.tensor(grid_representation,
                                               dtype=torch.float32).contiguous().view(1,
                                                                                      flags["grid_size"] ** 2,
                                                                                      grid_vector_size).to(DEVICE)

        # render each step of the episode
        if flags['render_episode']:
            env.render_episode(mission=instruction,
                               countdown=(flags["episode_len"] - t),
                               actions=actions,
                               weight=weight,
                               verb_in_command=verb_in_command,
                               save_path=visualization_path,
                               save_fig=False)

        # action by policy
        empty_cell = env.is_empty_cell(env.get_current_agent_position())
        all_actions = not empty_cell
        if flags['type_grammar'] == 'simple_intrans':
            log_prob, entropy, policy_all_probs, action = \
                listener_agent.act(state=(grid_representation, speaker_out),
                                   validate=validation)
        else:
            log_prob, entropy, policy_all_probs, action = \
                listener_agent.act(state=(grid_representation, speaker_out),
                                   validate=validation, all_actions=all_actions)

        # reward at each time-step;
        # done flag indicates whether the task was completed
        reward, done = env.step(action)
        actions += action + ' '

        rewards.append(reward)
        log_probs.append(log_prob.squeeze(0))
        entropy_term += entropy

        # ==================================Intrinsic Reward===================================== #
        # if not validation:
        #     MC_reward = 0.
        #     # TODO: experiment with bigger batches
        #     MC_batch_size = 3
        #
        #     with torch.no_grad():
        #         speaker_, listener_ = copy_models()
        #         # speaker_agent_local = SpeakerAgent(num_msgs=num_msgs, msg_len=msg_len, comm_type=flags['comm_type'],
        #         #                              temp=flags['temp'], speaker_model=speaker_bot_local, device=DEVICE)
        #
        #         # =======================Speaker Influence rewards======================== #
        #         # all_vars['speaker_bot'].eval()
        #         # all_vars['listener_bot'].eval()
        #         P_probs = policy_all_probs.detach() + 1e-8  # here P is a function of both msg, grid
        #         Q_probs = torch.zeros(1, num_actions).to(DEVICE)  # here Q is a function of only grid
        #         for _ in range(MC_batch_size):
        #             # # msg_sample, msg_log_prob_sample = speaker_out.detach(), msg_log_prob.detach()
        #             # concept = torch.tensor(concept_representation[:12], dtype=torch.float32).unsqueeze(0).to(DEVICE)
        #             # msg_sample, msg_log_prob_sample = speaker_(data_input=concept, comm_channel=speaker_agent.comm,
        #             #                                            validation=validation)
        #             msg_sample, msg_log_prob_sample = prior_probability(message=speaker_out.detach().cpu().numpy(),
        #                                                                 msg_dim=msg_len)
        #             msg_sample, msg_log_prob_sample = torch.tensor(msg_sample, dtype=torch.float32).to(DEVICE), \
        #                                               torch.tensor(msg_log_prob_sample, dtype=torch.float32).to(DEVICE)
        #
        #             msg_sample = msg_sample.view(1, -1)
        #             Q_probs_conditional = torch.softmax(listener_(grid_image=grid_representation,
        #                                                           speaker_out=msg_sample), dim=-1) + 1e-8
        #             # _, _, Q_probs_conditional, _ =  listener_.act(state=(grid_representation, msg_sample),
        #             #                                validate=validation)
        #             Q_probs += Q_probs_conditional * torch.exp(msg_log_prob_sample)
        #         Q_probs = torch.softmax(Q_probs, dim=-1)
        #         MC_reward += LAMBDA_influence * (P_probs * (P_probs / Q_probs).log()).mean()
        #         influence_rewards.append(MC_reward)
        #         # print(influence_rewards)
        #         # all_vars['speaker_bot'].train()
        #         # all_vars['listener_bot'].train()

        if done:
            # render each step of the episode
            if flags['render_episode']:
                env.render_episode(mission=instruction,
                                   countdown=(flags["episode_len"] - t - 1),
                                   actions=actions,
                                   weight=weight,
                                   verb_in_command=verb_in_command,
                                   save_path=visualization_path,
                                   save_fig=SAVE_FIG)
            val = torch.tensor(0., device=DEVICE)
            break

    if validation:
        return np.array(rewards).sum(), posdis_composition_array, bosdis_composition_array

    rewards[-1] += LAMBDA_coverage * (- d_loss.item())  # 0.0004
    train_rewards = torch.tensor(rewards).to(DEVICE)
    # train_rewards += torch.tensor(influence_rewards).to(DEVICE)

    # ====================== update discriminator memory ================== #
    if not validation:
        if rewards[-1] >= 1.0:
            if flags['type_grammar'] == 'simple_intrans':
                d_MEMORY.push(speaker_out.detach().squeeze(0), shape_lab, color_lab)
            else:
                d_MEMORY.push(speaker_out.detach().squeeze(0), shape_lab, color_lab, task_lab)
        elif rewards[-1] < 1.0 and random.random() > negative_sampling_prob:
            if flags['type_grammar'] == 'simple_intrans':
                d_MEMORY.push(speaker_out.detach().squeeze(0), shape_lab, color_lab)
            else:
                d_MEMORY.push(speaker_out.detach().squeeze(0), shape_lab, color_lab, task_lab)

    vals = []
    for t in reversed(range(len(rewards))):
        val = train_rewards[t] + GAMMA * val
        vals.insert(0, val)

    vals = torch.stack(vals)
    log_probs = torch.stack(log_probs)
    advantage = vals.detach()

    agent_loss = (-log_probs * advantage.detach()).mean()
    net_loss = agent_loss - LAMBDA * entropy_term
    return net_loss, train_rewards, np.array(influence_rewards).sum()


def main():
    # Create directory for visualizations if it doesn't exist.
    flags['output_directory'] = os.path.join(os.getcwd(), flags['output_directory'])
    if flags['output_directory']:
        visualization_path = flags['output_directory']
        if not os.path.exists(visualization_path):
            os.mkdir(visualization_path)

    # initializing the vocabulary
    intransitive_verbs = flags["intransitive_verbs"].split(',')
    transitive_verbs = flags["transitive_verbs"].split(',')
    nouns = flags["nouns"].split(',')
    color_adjectives = flags["color_adjectives"].split(',') if flags["color_adjectives"] else []
    size_adjectives = flags["size_adjectives"].split(',') if flags["size_adjectives"] else []

    # initializing the environment
    env = gCommEnv(
        intransitive_verbs=intransitive_verbs, transitive_verbs=transitive_verbs, nouns=nouns,
        color_adjectives=color_adjectives, size_adjectives=size_adjectives,
        min_object_size=flags["min_object_size"], max_object_size=flags["max_object_size"],
        save_directory=flags["output_directory"], grid_size=flags["grid_size"],
        type_grammar=flags["type_grammar"], maze_complexity=flags["maze_complexity"],
        maze_density=flags["maze_density"], enable_maze=flags["enable_maze"],
        lights_out=flags["lights_out"], obstacles_flag=flags['obstacles_flag'],
        keep_fixed_weights=flags["keep_fixed_weights"], all_light=flags['all_light'],
        episode_len=flags["episode_len"], wait=flags['wait_time'])

    # generating episodes
    task_rewards = {"'walk'": []}
    for Episode_count in range(1, flags["num_episodes"] + 1):

        # ==================== Train =================== #
        if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
            all_vars['speaker_bot'].train(True)
        all_vars['listener_bot'].train(True)
        all_vars['optimizer'].zero_grad()
        # run a single training loop
        net_loss, train_rewards, train_influence_rewards = single_loop(env, validation=False)
        net_loss.backward()
        all_vars['optimizer'].step()

        # ==================== validation ====================== #
        if Episode_count % 50 == 0:
            val_rewards = 0
            num_val_iter = 20  # number of validation loops/episodes to be run
            if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
                all_vars['speaker_bot'].eval()
            all_vars['listener_bot'].eval()
            with torch.no_grad():
                composition_dict = dict()
                posdis_composition_array = [[dict() for _ in range(3)] for _ in
                                            range(3)]  # O num_msgs=3, I num_attributes=3
                bosdis_composition_array = [[], []]  # attribute arr, message_arr
                for _ in range(num_val_iter):
                    val_reward, posdis_composition_array, bosdis_composition_array = \
                        single_loop(env,
                                    composition_dict=composition_dict,
                                    posdis_composition_array=posdis_composition_array,
                                    bosdis_composition_array=bosdis_composition_array,
                                    validation=True)
                    val_rewards += val_reward / num_val_iter
            # print('episode: {} | val-reward: {}'.format(Episode_count, val_rewards))
            # task_rewards["'walk'"].extend([val_rewards])

            # =================Measure correlation================== #
            c_p, c_s = topsim_metric(composition_dict)
            # corr_pear.extend([c_p])
            # corr_spear.extend([c_s])
            posdis = posdis_metric(posdis_composition_array)
            posdis2 = posdis_metric2(attributes=torch.tensor(bosdis_composition_array[0]),
                                     messages=torch.tensor(bosdis_composition_array[1]))
            bosdis = bosdis_metric(attributes=torch.tensor(bosdis_composition_array[0]),
                                   messages=torch.tensor(bosdis_composition_array[1]),
                                   vocab_size=msg_len)
            # bosdis_arr.extend([bosdis])
            # influence.extend([train_influence_rewards])
            print('episode: {} | val-reward: {} | topsim: {} | posdis: {} | bosdis: {}'.format(Episode_count,
                                                                                               val_rewards, c_p,
                                                                                               max(posdis, posdis2),
                                                                                               bosdis))

            log_file.write('Episode: ' + str(Episode_count) + ' | Train Reward: ' + str(train_rewards.sum().item()) +
                           ' | Val Reward: ' + str(val_rewards.sum().item()) + ' | Train Loss: ' + str(
                net_loss.item()) +
                           ' | topsim (Pearson): ' + str(c_p) + ' | topsim (Spearman): ' + str(c_s) +
                           ' | posdis: ' + str(posdis) + '/' + str(posdis2) + ' | bosdis: ' + str(bosdis) + "\n")

        # ========================== Plot ============================= #
        if Episode_count % 1000 == 0:
            #     print('------------------Generating plots------------------------')
            #     generate_task_progress(task_reward_dict=task_rewards, color='m',
            #                            file_name=os.path.join(plot_path, 'task_progress.png'))
            #     plot_metrics(corr_pear, corr_spear, posdis, bosdis,
            #                  file_name=os.path.join(plot_path, 'compositionality.png'))
            #     plot_d_loss_progress(net_d_loss, file_name=os.path.join(plot_path, 'd_loss.png'))
            #     plot_influence_rewards(influence, file_name=os.path.join(plot_path, 'influence_rewards.png'))
            print(composition_dict)

        if Episode_count % train_discriminator_period == 0:
            # ======================training discriminator==================== #
            train_discriminator()

        # ===================== save model ====================== #
        if save_model_flag is True:
            if Episode_count % 10000 == 0:
                print('------------------Saving model checkpoint------------------\n')
                save_models(iteration=Episode_count)

        log_file.flush()


if __name__ == "__main__":
    # =================initialize model params and environment============== #

    # ================== Listener-Bot ====================== #
    oracle = True if flags['comm_type'] == 'oracle' else False
    if flags['type_grammar'] == 'simple_intrans':
        listener_bot = ListenerBot(grid_size=flags['grid_size'], num_msgs=num_msgs, msg_len=msg_len,
                                   in_channels=18, out_channels=20, input_dim=320, hidden_dim1=150,
                                   hidden_dim2=30, num_actions=num_actions, oracle=oracle).to(DEVICE)
    else:
        listener_bot = ListenerBot_MT(grid_size=flags['grid_size'], num_msgs=num_msgs, msg_len=msg_len,
                                   in_channels=18, out_channels=20, input_dim=320, hidden_dim1=150,
                                   hidden_dim2=30, num_actions=num_actions, oracle=oracle).to(DEVICE)
    listener_agent = ListenerAgent(listener_model=listener_bot)

    # ================== Speaker-Bot ====================== #
    hidden_size = msg_len
    speaker_bot = SpeakerBot(comm_type=flags['comm_type'], input_size=12, hidden_size=hidden_size,
                             output_size=msg_len, num_msgs=num_msgs, device=DEVICE).to(DEVICE)
    speaker_agent = SpeakerAgent(num_msgs=num_msgs, msg_len=msg_len, comm_type=flags['comm_type'],
                                 temp=flags['temp'], speaker_model=speaker_bot, device=DEVICE)

    # ================== Discriminator ===================== #
    if flags['type_grammar'] == 'simple_intrans':
        discriminator = Discriminator(num_msgs=num_msgs, msg_dim=4).to(DEVICE)
    else:
        discriminator = Discriminator_MT(num_msgs=num_msgs, msg_dim=4).to(DEVICE)
    discriminator_optimizer = optim.Adam(discriminator.parameters(), lr=lr_discriminator)
    classification_loss = nn.CrossEntropyLoss()
    d_MEMORY = ReplayMemory(d_memory_size)

    # ================== parameters ===================== #
    all_params = list(listener_agent.listener_model.parameters())
    if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
        all_params += list(speaker_agent.speaker_model.parameters())
    # if flags['enable_intrinsic']:
    #     all_params += list(discriminator.parameters())

    optimizer = optim.AdamW(all_params, lr=lr_rest)
    all_vars = {'listener_bot': listener_bot, 'speaker_bot': speaker_bot,
                'discriminator': discriminator, 'optimizer': optimizer,
                'discriminator_optimizer': discriminator_optimizer}

    print('\n=================== Our Model: {} ===================\n'.format('Intrinsic Speaker (visual split)'))
    main()

    log_file.close()
