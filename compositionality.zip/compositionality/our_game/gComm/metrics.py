import numpy as np
import pandas as pd
import torch
from collections import defaultdict
from gComm.helpers import display_table, _hashable_tensor, entropy_dict


def hamming_dist(concept1, concept2):
    """
        Calculate the hamming distance of two concepts.
        The input concepts should be tuple, e.g. ('red','box')
        We require concept1 and 2 have the same number of attributes,
        i.e., len(concept1)==len(concept2)
    """
    acc_dist = 0
    for i in range(len(concept1)):
        if concept1[i] != concept2[i]:
            acc_dist += 1

    return acc_dist


def edit_dist(str1, str2):
    """
        Calculate the edit distance of two strings.
        Insert/delete/replace all cause 1.
    """
    len1, len2 = len(str1), len(str2)
    DM = [0]
    for i in range(len1):
        DM.append(i + 1)

    for j in range(len2):
        DM_new = [j + 1]
        for i in range(len1):
            tmp = 0 if str1[i] == str2[j] else 1
            new = min(DM[i + 1] + 1, DM_new[i] + 1, DM[i] + tmp)
            DM_new.append(new)
        DM = DM_new

    return DM[-1]


def topsim_metric(msg):
    """
        Calculate the compositionalities using metric mentioned in:
        Language as an evolutionary system -- Appendix A (Kirby 2005)
        Input: dictionary
            msg = {('0', '0'):'aa', ('0', '1'):'bb', ('1', '0'):'ab', ('1', '1'):'ba'}
            keys = concept symbols ('<shape>', '<color>')
            values = message symbols
        Output:
            corr_pearson:   person correlation
            corr_spearman:  spearman correlation
    """
    keys_list = list(msg.keys())
    concept_pairs = []
    message_pairs = []
    # ===== Form concepts and message pairs ========
    for i in range(len(keys_list)):
        # for j in range(i+1, len(keys_list)):
        for j in range(len(keys_list)):
            tmp1 = (keys_list[i], keys_list[j])
            concept_pairs.append((keys_list[i], keys_list[j]))
            tmp2 = (msg[tmp1[0]], msg[tmp1[1]])
            message_pairs.append(tmp2)

    # ===== Calculate distant for these pairs ======
    concept_HD = []
    message_ED = []
    for i in range(len(concept_pairs)):
        concept1, concept2 = concept_pairs[i]
        message1, message2 = message_pairs[i]
        concept_HD.append(hamming_dist(concept1, concept2))
        message_ED.append(edit_dist(message1, message2))

    if np.sum(message_ED) == 0:
        message_ED = np.asarray(message_ED) + 0.1
        message_ED[-1] -= 0.01

    dist_table = pd.DataFrame({'HD': np.asarray(concept_HD),
                               'ED': np.asarray(message_ED)})
    corr_pearson = dist_table.corr()['ED']['HD']
    corr_spearman = dist_table.corr('spearman')['ED']['HD']

    return corr_pearson, corr_spearman


def MI(dataframe):
    net_val = dataframe.to_numpy().sum()
    mi = 0
    for c in dataframe.index:
        p_c = (dataframe.loc[c].sum() / net_val) + 1e-5
        for m in dataframe.columns:
            p_m = (dataframe[m].sum() / net_val) + 1e-5
            p_cm = (dataframe[m].loc[c] / net_val) + 1e-5
            mi += p_cm * np.log(p_cm/(p_c * p_m))
    return mi

def entropy(dataframe_arr):
    new_df = pd.concat(dataframe_arr).fillna(0)
    ent_m = 0
    net_val = new_df.to_numpy().sum()
    for m in new_df.columns:
        p_m = (new_df[m].sum() / net_val) + 1e-5
        ent_m = ent_m - (p_m * np.log(p_m))
    return ent_m

def posdis_metric(count_array):
    """
    positional disentanglement: https://aclanthology.org/2020.acl-main.407.pdf
    """
    posdis = 0
    for arr_ind, arr in enumerate(count_array):
        mi = []
        for df_ind, df in enumerate(arr):
            count_array[arr_ind][df_ind] = pd.DataFrame.from_dict(df).fillna(0)
            mi.append(MI(count_array[arr_ind][df_ind]))
        mi.sort(reverse=True)
        ent = entropy(count_array[arr_ind])
        posdis += (1/len(count_array)) * ((mi[0] - mi[1]) / ent)  # num_msgs = len(count_array)
    return posdis

def posdis_metric2(attributes: torch.Tensor, messages: torch.Tensor) -> float:
    return gap_mi_first_second(attributes, messages)

# for bosdis
def gap_mi_first_second(attributes, representations):
    gaps = torch.zeros(representations.size(1))
    non_constant_positions = 0.0

    for j in range(representations.size(1)):
        symbol_mi = []
        h_j = None
        for i in range(attributes.size(1)):
            x, y = attributes[:, i], representations[:, j]
            info = mutual_info(x, y)
            symbol_mi.append(info)

            if h_j is None:
                h_j = calc_entropy(y)

        symbol_mi.sort(reverse=True)

        if h_j > 0.0:
            gaps[j] = (symbol_mi[0] - symbol_mi[1]) / h_j
            non_constant_positions += 1

    score = gaps.sum() / non_constant_positions
    return score.item()

# for bosdis
def mutual_info(xs, ys):
    """
    I[x, y] = E[x] + E[y] - E[x,y]
    """
    e_x = calc_entropy(xs)
    e_y = calc_entropy(ys)

    xys = []

    for x, y in zip(xs, ys):
        xy = (_hashable_tensor(x), _hashable_tensor(y))
        xys.append(xy)

    e_xy = calc_entropy(xys)

    return e_x + e_y - e_xy

# for bosdis
def calc_entropy(messages):
    """
    >>> messages = torch.tensor([[1, 2], [3, 4]])
    >>> np.allclose(calc_entropy(messages), 1.0)
    True
    """
    freq_table = defaultdict(float)

    for m in messages:
        m = _hashable_tensor(m)
        freq_table[m] += 1.0

    return entropy_dict(freq_table)

def bosdis_metric(attributes: torch.Tensor, messages: torch.Tensor, vocab_size: int) -> float:
    batch_size = messages.size(0)
    histogram = torch.zeros(batch_size, vocab_size, device=messages.device)
    for v in range(vocab_size):
        histogram[:, v] = messages.eq(v).sum(dim=-1)
    # histogram = histogram[:, 1:]  # ignoring eos symbol
    # print('histogram:', histogram)
    # print('attributes:', attributes)
    return gap_mi_first_second(attributes, histogram)


if __name__ == "__main__":
    print('# ================== Demos ================== #')
    # Demo 1: perfectly compositional
    messages = {('green', 'box'): 'aa', ('blue', 'box'): 'ba', ('green', 'circle'): 'ab', ('blue', 'circle'): 'bb'}
    c_p, c_s = topsim_metric(msg=messages)
    display_table(messages=messages, protocol='perfectly compositional', corr=(c_p, c_s))

    # Demo 2: two different objects (concepts) map to the same set of messages
    messages = {('green', 'box'): 'ab', ('blue', 'box'): 'ba', ('green', 'circle'): 'ab', ('blue', 'circle'): 'bb'}
    c_p, c_s = topsim_metric(msg=messages)
    display_table(messages=messages, protocol='non surjective and non injective', corr=(c_p, c_s))

    # Demo 3: holistic language (one-to-one mapping but not fully systematic)
    messages = {('green', 'box'): 'aA', ('blue', 'box'): 'bB', ('green', 'circle'): 'aB', ('blue', 'circle'): 'bA'}
    c_p, c_s = topsim_metric(msg=messages)
    display_table(messages=messages, protocol='holistic', corr=(c_p, c_s))

    # Demo 3: ambiguous language
    messages = {('green', 'box'): 'aA', ('blue', 'box'): 'aA', ('green', 'circle'): 'aB', ('blue', 'circle'): 'bB'}
    c_p, c_s = topsim_metric(msg=messages)
    display_table(messages=messages, protocol='ambiguous language', corr=(c_p, c_s))