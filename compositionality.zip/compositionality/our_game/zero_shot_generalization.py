"""
baselines:
        Random, Fixed, Perfect, Oracle, Simple (Categorical)

Actions:
        left = 0
        right = 1
        forward = 2
        backward = 3
        push = 4
        pull = 5
        pickup = 6
        drop = 7
"""
import os
from zero_shot_arguments import Arguments, ValInstructionDict
from gComm.gComm_env import gCommEnv
from baseline_models import SpeakerBot, ListenerBot, ListenerBot_MT
from gComm.agent import SpeakerAgent, ListenerAgent


from pathlib import Path
import argparse
import pandas as pd
import numpy as np
import torch
from collections import OrderedDict
from IPython.display import display

SAVE_FIG = False  # save test episodes?
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

GAMMA = 0.9  # discount rate
LAMBDA = 0.01  # hyper parameter for entropy
num_msgs = 3  # n_m of the communication channel
# d_m of the communication channel

visualization_path = None
EXPERIMENT = "visual"
# composition_dict = OrderedDict({('square', 'red'): '00', ('square', 'blue'): '00', ('square', 'yellow'): '00',
#                                 ('square', 'green'): '00',
#                                 ('cylinder', 'red'): '00', ('cylinder', 'blue'): '00', ('cylinder', 'yellow'): '00',
#                                 ('cylinder', 'green'): '00',
#                                 ('circle', 'red'): '00', ('circle', 'blue'): '00', ('circle', 'yellow'): '00',
#                                 ('circle', 'green'): '00',
#                                ('diamond', 'red'): '00', ('diamond', 'blue'): '00', ('diamond', 'yellow'): '00',
#                                 ('diamond', 'green'): '00'})
composition_dict = dict()
shape_dict = {'0': 'square', '1': 'cylinder', '2': 'circle', '3': 'diamond'}
color_dict = {'0': 'red', '1': 'blue', '2': 'yellow', '3': 'green'}


# =======================Save Models======================== #
def load_models(model, model_name, iteration, model_load_path):
    # for model_name, model in all_vars.items():
    if model_name in ['speaker_bot', 'listener_bot']:
        weights_path = os.path.join(model_load_path, str(iteration) + '_' + model_name)
        if not os.path.exists(weights_path):
            weights_path = os.path.join(model_load_path, str(iteration) + '_' + model_name + '.zip')
        model.load_state_dict(torch.load(weights_path))
        model.eval()
        # print(model_name + '_weights loaded')
    else:
        print('unexpected model name: ', model_name)


def single_loop(env, flags, speaker_agent=None, listener_agent=None, validation=True, zero_shot=True):
    while True:
        instruction, verb_in_command = env.generate_world(
            other_objects_sample_percentage=flags['other_objects_sample_percentage'],
            max_other_objects=flags['max_objects'],
            min_other_objects=flags['min_other_objects'],
            num_obstacles=flags['num_obstacles'])
        if validation and not zero_shot:
            break
        if validation and EXPERIMENT in env._world_type:
            break

    # log_file.write(instruction + '\n')

    # concept input (encoded instruction and target information)
    concept_representation, weight = env.concept_input(verb_in_command)

    actions = ''
    log_probs = []
    rewards = []
    entropy_term = torch.tensor(0.).to(DEVICE)

    # speaker model processes instruction based on baseline specification
    if flags["comm_type"] == 'perfect':
        speaker_out = speaker_agent.transmit(concept=concept_representation, validation=validation)
    else:
        speaker_out, _ = speaker_agent.transmit(concept=concept_representation, validation=validation)
        speaker_out = speaker_out.view(1, -1)

    if validation:
        symbols = [str(torch.argmax(speaker_out[:, :4]).item()), str(torch.argmax(speaker_out[:, 4:8]).item()),
                   str(torch.argmax(speaker_out[:, 8:12]).item())]
        str_obs = tuple([str(torch.argmax(torch.tensor(concept_representation)[4:8]).item()),
                         str(torch.argmax(torch.tensor(concept_representation)[8:12]).item()),
                         str(torch.argmax(torch.tensor(concept_representation)[-4:]).item())])
        composition_dict[str_obs] = ''.join(symbols)

    # time-steps

    for t in range(flags["episode_len"]):
        # grid input
        if flags["grid_input_type"] == "image":
            grid_representation = env.grid_image_input()  # [img_height, img_width, 3]
        elif flags["grid_input_type"] == "vector":
            grid_vector_size = 17
            grid_representation = env.grid_input()  # [grid_height, grid_width, num_channels]
            grid_representation = torch.tensor(grid_representation,
                                               dtype=torch.float32).contiguous().view(1,
                                                                                      flags["grid_size"] ** 2,
                                                                                      grid_vector_size).to(DEVICE)
        # baseline: ORACLE LISTENER
        elif flags["grid_input_type"] == "with_target":
            grid_representation = \
                env.grid_input(specify_target=True)  # [grid_height, grid_width, num_channels+1]
            grid_vector_size = 18
            grid_representation = torch.tensor(grid_representation,
                                               dtype=torch.float32).contiguous().view(1,
                                                                                      flags["grid_size"] ** 2,
                                                                                      grid_vector_size).to(DEVICE)

        # render each step of the episode
        if flags['render_episode']:
            env.render_episode(mission=instruction,
                               countdown=(flags["episode_len"] - t),
                               actions=actions,
                               weight=weight,
                               verb_in_command=verb_in_command,
                               save_path=visualization_path,
                               save_fig=False)

        # action by policy
        if flags['type_grammar'] == 'simple_intrans':
            log_prob, entropy, _, action = \
                listener_agent.act(state=(grid_representation, speaker_out), validate=validation)
        else:
            empty_cell = env.is_empty_cell(env.get_current_agent_position())
            all_actions = not empty_cell
            log_prob, entropy, _, action = \
                listener_agent.act(state=(grid_representation, speaker_out), validate=validation, all_actions=all_actions)
        # log_prob, entropy, _, action = listener_agent.act(state=(grid_representation, speaker_out), validate=validation)

        # reward at each time-step;
        # done flag indicates whether the task was completed
        reward, done = env.step(action)
        actions += action + ' '

        rewards.append(reward)
        log_probs.append(log_prob.squeeze(0))
        entropy_term += entropy

        if done:
            # render each step of the episode
            if flags['render_episode']:
                env.render_episode(mission=instruction,
                                   countdown=(flags["episode_len"] - t - 1),
                                   actions=actions,
                                   weight=weight,
                                   verb_in_command=verb_in_command,
                                   save_path=visualization_path,
                                   save_fig=SAVE_FIG)
            val = torch.tensor(0., device=DEVICE)
            break

    if validation:
        return np.array(rewards).sum()
    else:
        raise NotImplementedError


def main(flags, all_vars, speaker_agent, listener_agent):
    # Create directory for visualizations if it doesn't exist.
    flags['output_directory'] = os.path.join(os.getcwd(), flags['output_directory'])
    if flags['output_directory']:
        visualization_path = flags['output_directory']
        if not os.path.exists(visualization_path):
            os.mkdir(visualization_path)

    # initializing the vocabulary
    intransitive_verbs = flags["intransitive_verbs"].split(',')
    transitive_verbs = flags["transitive_verbs"].split(',')
    nouns = flags["nouns"].split(',')
    color_adjectives = flags["color_adjectives"].split(',') if flags["color_adjectives"] else []
    size_adjectives = flags["size_adjectives"].split(',') if flags["size_adjectives"] else []

    # initializing the environment
    env = gCommEnv(
        intransitive_verbs=intransitive_verbs, transitive_verbs=transitive_verbs, nouns=nouns,
        color_adjectives=color_adjectives, size_adjectives=size_adjectives,
        min_object_size=flags["min_object_size"], max_object_size=flags["max_object_size"],
        save_directory=flags["output_directory"], grid_size=flags["grid_size"],
        type_grammar=flags["type_grammar"], maze_complexity=flags["maze_complexity"],
        maze_density=flags["maze_density"], enable_maze=flags["enable_maze"],
        lights_out=flags["lights_out"], obstacles_flag=flags['obstacles_flag'],
        keep_fixed_weights=flags["keep_fixed_weights"], all_light=flags['all_light'],
        episode_len=flags["episode_len"], wait=flags['wait_time'])

    # generating episodes

    val_rewards = 0
    if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
        all_vars['speaker_bot'].eval()
    # else:
    #     raise NotImplementedError

    all_vars['listener_bot'].eval()
    with torch.no_grad():
        for _ in range(flags['num_val_episode']):
            val_reward = single_loop(env, flags, speaker_agent, listener_agent, validation=True, zero_shot=True)
            val_rewards += val_reward
    val_rewards = val_rewards / flags['num_val_episode']
    print('val-reward: {}'.format(val_rewards))
    return val_rewards
    # df = pd.DataFrame.from_dict(composition_dict, orient='index')
    # display(df)
    # print("=====================================\n")
    # log_file.write('val-reward: {}'.format(val_rewards))


# if __name__ == "__main__":
def zero_shot_main(weights_iteration):
    parent_parser = Arguments()
    parser = argparse.ArgumentParser(description='zero shot validation parameters simple speaker',
                                     parents=[parent_parser])
    parser.add_argument('--num_val_episode', type=int, default=100,
                        help='number of episodes to check zero shot generalisation')
    # parser.add_argument('--weights_iteration', type=int, default=400000, help='pre-trained weights iteration')
    parser.add_argument('--exp_id', type=int, required=False, default=1, help='experiment id')
    parser.add_argument('--zero_shot_flag', type=bool, default=True, help='if False, print composition_dict')

    flags = vars(parser.parse_args())
    if flags['comm_type'] == 'binary':
        msg_len = 2  # (binary)
    else:
        msg_len = 4  # (categorical or others)

    # number of actions by Listener-Bot
    num_actions = 4
    if flags['type_grammar'] == 'simple_trans':
        num_actions += len(flags['transitive_verbs'].split(','))

    # ======================= Data storage paths ========================== #
    run_id = flags['run_id']
    path = os.path.join(os.getcwd(), "our_game/intrinsic_speaker_data/") + "run_" + str(
        run_id) + "/"
    # path = os.path.join(os.getcwd(), "model_analysis/trained_baselines/push-pull-mod/" + "intrinsic/") + "run_" + str(run_id) + "/"
    model_load_path = Path(path + "checkpoint_dir")
    # =================initialize model params and environment============== #

    # ================== Listener-Bot ====================== #
    # oracle = True if flags['comm_type'] == 'oracle' else False

    # log_file = open(path + "zero_shot_weights_{}_{}.txt".format(flags['weights_iteration'], flags['exp_id']), "w")
    # log_file.write(str(flags) + '\n')
    # val_instruction_stat = ValInstructionDict()

    oracle = False
    # if flags['type_grammar'] == 'simple_intrans':
    listener_bot = ListenerBot(grid_size=flags['grid_size'], num_msgs=num_msgs, msg_len=msg_len,
                               in_channels=18, out_channels=20, input_dim=320, hidden_dim1=150,
                               hidden_dim2=30, num_actions=num_actions, oracle=oracle).to(DEVICE)
    # else:
    #     listener_bot = ListenerBot_MT(grid_size=flags['grid_size'], num_msgs=num_msgs, msg_len=msg_len,
    #                                in_channels=18, out_channels=20, input_dim=320, hidden_dim1=150,
    #                                hidden_dim2=30, num_actions=num_actions, oracle=oracle).to(DEVICE)

    print("================= {} : {} ====================".format(weights_iteration, flags['run_id']))
    load_models(listener_bot, 'listener_bot', weights_iteration, model_load_path)
    listener_agent = ListenerAgent(listener_model=listener_bot)

    # ================== Speaker-Bot ====================== #
    hidden_size = msg_len
    speaker_bot = SpeakerBot(comm_type=flags['comm_type'], input_size=12, hidden_size=hidden_size,
                             output_size=msg_len, num_msgs=num_msgs, device=DEVICE).to(DEVICE)
    if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
        load_models(speaker_bot, 'speaker_bot', weights_iteration, model_load_path)
    speaker_agent = SpeakerAgent(num_msgs=num_msgs, msg_len=msg_len, comm_type=flags['comm_type'],
                                 temp=flags['temp'], speaker_model=speaker_bot, device=DEVICE)

    all_params = list(listener_agent.listener_model.parameters())
    if flags['comm_type'] in ['categorical', 'continuous', 'binary']:
        all_params += list(speaker_agent.speaker_model.parameters())

    # optimizer = optim.Adam(all_params, lr=1e-3)
    all_vars = {'listener_bot': listener_bot, 'speaker_bot': speaker_bot}
    return main(flags, all_vars, speaker_agent, listener_agent)

    # log_file.write(val_instruction_stat.__str__())
    # log_file.close()
