import os
import numpy as np
from collections import OrderedDict


class ACL:
    def __init__(self, num_tasks):
        # self.task_map = OrderedDict({0: 'walk', 1: 'push', 2: 'pull'})
        self.num_tasks = num_tasks
        self.task_map = OrderedDict({0: 'push', 1: 'pull'})

    @staticmethod
    def process_lp_vals(val_rew, new_val_rew):
        '''
        :param val_rew: 1d array of old reward for all tasks
        :param new_val_rew: 1d array of new validation reward for all tasks
        :return: converts LP to a distribution
        '''
        diff = np.abs(new_val_rew - val_rew)
        return (np.exp(diff) / np.exp(diff).sum())

    def curriculum(self, all_probs):
        # all_probs is a list of a 1d array
        target_action = np.random.multinomial(n=1, pvals=all_probs, size=1)
        target_action = target_action[0]
        target_action = target_action.argmax()
        return target_action, self.task_map[target_action]
